# Accessibility Baseline & Repository Architecture Audit

## 1. Introduction

Website accessibility helps ensure that people with different abilities can access and interact with web content.

This project evaluates a public-facing website using Google Lighthouse and manual keyboard navigation testing. It also establishes a maintainable repository structure for future full-stack development.

## 2. Project Objectives

The main objectives are:

1. Evaluate website accessibility.
2. Perform keyboard-only navigation testing.
3. Identify five genuine accessibility or architecture issues.
4. Record evidence and assess the impact of each finding.
5. Recommend appropriate remediation measures.
6. Create a maintainable project repository.

## 3. Target Website

**Website Name:** National Portal of India

**Website URL:** https://www.india.gov.in/

**Audit Date:** 30 October 2026

**Testing Tool:** Google Chrome Lighthouse

**Testing Device:** Desktop

## 4. Audit Methodology

The audit consists of the following activities.

### 4.1 Automated Accessibility Testing

Google Lighthouse is used to evaluate selected accessibility requirements and identify potential issues.

The report is examined to identify failed accessibility checks and relevant recommendations.

### 4.2 Manual Keyboard Testing

Keyboard-only testing is performed to evaluate navigation and interaction without relying on a mouse.

The following areas are examined:

* Tab navigation.
* Visible keyboard focus.
* Enter key interaction.
* Space key interaction.
* Reverse navigation using Shift + Tab.
* Potential keyboard traps.

### 4.3 Findings Documentation

Each verified finding is recorded with its location, evidence, severity, user impact, recommended fix, owner, and status.

Relevant WCAG criteria are included where applicable.

## 5. Lighthouse Results

**Accessibility Score:** To be entered from the actual Lighthouse report.

**Audit Configuration:** Desktop accessibility audit.

**Summary of Results:** To be completed using the actual Lighthouse findings.

The Lighthouse screenshots are stored in the `screenshots/` directory.

## 6. Keyboard Navigation Results

The keyboard testing checklist is available at:

`tests/manual/keyboard-test-checklist.md`

The checklist records the expected behavior and actual results for each test.

Any observed problems are documented with their location and reproduction steps.

## 7. Accessibility and Architecture Findings

Five verified findings are documented in:

`docs/accessibility-audit.csv`

Each finding includes:

* Unique issue ID.
* Page or component.
* Applicable WCAG reference, where relevant.
* Evidence.
* Severity.
* User impact.
* Recommended fix.
* Responsible person.
* Current status.

Findings are prioritized according to their impact on users and the importance of the affected functionality.

## 8. Remediation Recommendations

Recommended remediation should address the specific problems identified during the audit.

Potential remediation approaches include:

* Improving keyboard accessibility.
* Providing accessible names for form fields and controls.
* Adding appropriate alternative text to meaningful images.
* Improving text contrast where necessary.
* Correcting confusing heading structures.

These recommendations should be applied only where the corresponding problem has been verified.

## 9. Repository Architecture

The repository follows a monorepo approach.

### Client

The `client/` directory is reserved for frontend application code.

### Server

The `server/` directory is reserved for backend application code.

### Documentation

The `docs/` directory contains the audit report, findings worksheet, and architecture document.

### Testing

The `tests/` directory contains manual testing procedures and resources for future automated tests.

### Screenshots

The `screenshots/` directory contains evidence captured during the audit.

## 10. Limitations

The audit covers only the pages and interactions that were tested.

Lighthouse identifies certain accessibility issues but cannot detect every possible barrier.

Manual testing and further evaluation may be required to assess additional pages, user journeys, and accessibility requirements.

The audit does not independently establish full WCAG conformance.

## 11. Conclusion

The project combines automated accessibility evaluation, manual keyboard testing, structured findings documentation, and repository architecture planning.

The results provide a foundation for prioritizing accessibility improvements and organizing future full-stack development.
