# Manual Keyboard Testing Checklist

## 1. Website Information

**Project Name:** Accessibility Baseline & Repository Architecture Audit

**Website Name:** National Portal of India

**Website URL:** https://www.india.gov.in/

**Testing Date:** 30 October 2026

**Browser:** Google Chrome

**Operating System:** Windows

**Testing Method:** Manual Keyboard Navigation

## 2. Objective

The objective of this test is to evaluate whether the website can be navigated and operated using a keyboard without relying on a mouse.

The test focuses on keyboard navigation, visible focus indicators, keyboard interaction, reverse navigation, and potential keyboard traps.

## 3. Test Cases

### Test Case 1: Tab Navigation

**Test ID:** KB-001

**Purpose:** To verify that interactive elements can be reached using the Tab key.

**Procedure:**

1. Open the target website in Google Chrome.
2. Click an appropriate starting point on the webpage.
3. Press Tab repeatedly.
4. Observe the order in which links, buttons, and other interactive elements receive focus.
5. Record any interactive elements that cannot be reached or any unexpected navigation behavior.

**Expected Result:** Interactive elements should be reachable using the keyboard in a logical order.

**Actual Result:** Record the behavior observed during testing.

**Status:** Requires verification.

### Test Case 2: Visible Keyboard Focus

**Test ID:** KB-002

**Purpose:** To verify that users can identify which element currently has keyboard focus.

**Procedure:**

1. Open the website.
2. Press Tab to move between interactive elements.
3. Observe the currently focused element.
4. Check whether a visible outline, border, or another clear focus indicator is present.
5. Record any element where focus is difficult to identify.

**Expected Result:** The focused element should have a visible focus indicator.

**Actual Result:** Record the behavior observed during testing.

**Status:** Requires verification.

### Test Case 3: Enter Key Interaction

**Test ID:** KB-003

**Purpose:** To verify that links and applicable controls respond correctly to the Enter key.

**Procedure:**

1. Open the website.
2. Use Tab to focus a link or an appropriate interactive control.
3. Press Enter.
4. Observe whether the expected action occurs.
5. Repeat with other suitable controls where appropriate.

**Expected Result:** Links and applicable controls should perform their expected actions when activated using Enter.

**Actual Result:** Record the behavior observed during testing.

**Status:** Requires verification.

### Test Case 4: Space Key Interaction

**Test ID:** KB-004

**Purpose:** To verify that controls supporting Space activation respond correctly.

**Procedure:**

1. Open the website.
2. Use Tab to focus a suitable control, such as a checkbox or standard button.
3. Press Space.
4. Observe whether the control responds as expected.
5. Record any unexpected behavior.

**Expected Result:** Controls that support Space activation should respond correctly.

**Actual Result:** Record the behavior observed during testing.

**Status:** Requires verification.

**Note:** A normal link generally uses Enter for activation. Space is not expected to activate every type of control.

### Test Case 5: Reverse Keyboard Navigation

**Test ID:** KB-005

**Purpose:** To verify that users can navigate backward through interactive elements.

**Procedure:**

1. Open the website.
2. Press Tab several times.
3. Press Shift + Tab.
4. Observe whether focus moves to the previous focusable element.
5. Repeat the test across different sections of the page.

**Expected Result:** Shift + Tab should move focus backward through focusable elements in a predictable order.

**Actual Result:** Record the behavior observed during testing.

**Status:** Requires verification.

### Test Case 6: Keyboard Trap Detection

**Test ID:** KB-006

**Purpose:** To determine whether keyboard focus becomes unintentionally trapped within an interactive area.

**Procedure:**

1. Open the website.
2. Navigate using Tab.
3. Enter interactive areas such as menus or dialogs, if present.
4. Attempt to move forward and backward using Tab and Shift + Tab.
5. Check whether you can leave the interactive area using the keyboard.

**Expected Result:** Users should not become unintentionally trapped in an interactive component.

**Actual Result:** Record the behavior observed during testing.

**Status:** Requires verification.

## 4. Summary of Test Results

| Test ID | Test Name               | Expected Behavior                                      | Actual Result        | Status                |
| ------- | ----------------------- | ------------------------------------------------------ | -------------------- | --------------------- |
| KB-001  | Tab Navigation          | Interactive elements are reachable in a logical order. | Pending verification | Requires verification |
| KB-002  | Visible Keyboard Focus  | The focused element is visually identifiable.          | Pending verification | Requires verification |
| KB-003  | Enter Key               | Links and applicable controls activate as expected.    | Pending verification | Requires verification |
| KB-004  | Space Key               | Applicable controls respond as expected.               | Pending verification | Requires verification |
| KB-005  | Reverse Navigation      | Shift + Tab moves focus backward.                      | Pending verification | Requires verification |
| KB-006  | Keyboard Trap Detection | Focus is not unintentionally trapped.                  | Pending verification | Requires verification |

## 5. Issue Documentation

If a keyboard accessibility problem is identified, document the following information:

* Issue ID.
* Page or component where the problem occurs.
* Steps required to reproduce the problem.
* Expected behavior.
* Actual behavior.
* User impact.
* Recommended fix.
* Related finding ID in the accessibility audit worksheet.

Only confirmed problems should be recorded as accessibility failures.

## 6. Evidence Collection

Supporting screenshots should be saved in the project's `screenshots/` directory.

Suggested evidence filenames include:

* `keyboard-navigation.png`
* `keyboard-focus.png`
* `keyboard-issue.png`

Capture these screenshots only when they show the corresponding test or an observed issue.

## 7. Testing Limitations

This checklist covers the keyboard interactions tested on the selected website.

Results apply only to the pages, components, and interactions actually examined.

Additional testing may be necessary for other pages, forms, menus, dialogs, and interactive components.

## 8. Conclusion

The keyboard navigation assessment is intended to identify barriers that may affect users who rely on keyboard interaction.

The final conclusion should be completed after all test cases have been performed and their results recorded.

Verified issues should be added to the accessibility audit worksheet with appropriate evidence and remediation recommendations.
