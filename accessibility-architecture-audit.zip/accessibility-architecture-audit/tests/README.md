# Tests

## Purpose

This directory contains testing documentation and resources for future automated tests.

## Current Testing Resources

The `manual/` directory contains the keyboard navigation testing checklist.

## Testing Goals

* Document manual testing procedures.
* Record actual test results.
* Support repeatable testing.
* Identify regressions during future development.
* Provide a foundation for automated tests.

## Future Improvements

Automated tests may be introduced when the frontend and backend applications are implemented.

## Current Status

The directory establishes the initial testing structure.
