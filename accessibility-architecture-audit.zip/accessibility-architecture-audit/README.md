# Accessibility Baseline & Repository Architecture Audit

## 1. Project Overview

This project focuses on evaluating the accessibility of a public-facing website and establishing a maintainable full-stack project structure.

The audit uses Google Lighthouse and manual keyboard navigation testing to identify potential accessibility barriers and recommend improvements.

## 2. Objectives

* Evaluate website accessibility using Google Lighthouse.
* Perform manual keyboard-only navigation testing.
* Identify and document five accessibility or architecture findings.
* Record evidence, severity, user impact, and recommended fixes.
* Create a maintainable monorepo structure.
* Organize the frontend, backend, documentation, and testing resources.

## 3. Target Website

**Website:** National Portal of India

**URL:** https://www.india.gov.in/

## 4. Tools Used

* Google Chrome
* Google Lighthouse
* Windows Notepad
* GitHub
* CSV spreadsheet format
* Markdown documentation

## 5. Project Structure

```text
accessibility-architecture-audit/
├── client/
├── server/
├── docs/
├── tests/
├── screenshots/
├── .gitignore
└── README.md
```

## 6. Project Deliverables

The repository contains the following deliverables:

1. Accessibility audit report.
2. Accessibility findings worksheet.
3. Repository architecture documentation.
4. Manual keyboard testing checklist.
5. Lighthouse screenshots.
6. Project directory structure.

## 7. Testing Approach

The website is evaluated using automated accessibility checks and manual keyboard navigation tests.

The manual tests examine keyboard focus, navigation order, control interaction, reverse navigation, and potential keyboard traps.

## 8. Repository Architecture

The project uses a monorepo structure to organize related project resources in one repository.

* `client/` contains the frontend application foundation.
* `server/` contains the backend application foundation.
* `docs/` contains reports and documentation.
* `tests/` contains testing procedures.
* `screenshots/` contains audit evidence.

## 9. Limitations

The audit covers only the pages and interactions actually tested.

Automated accessibility tools cannot identify every accessibility barrier. Manual inspection is necessary, and the results do not independently establish complete WCAG conformance.

## 10. Conclusion

This project establishes an organized foundation for website accessibility evaluation and future full-stack development.

The documented findings and recommendations provide a starting point for improving accessibility, usability, and maintainability.

## 11. Project Status

The project status should be updated after the audit, documentation, and GitHub repository have been completed and verified.
